## What is a Application Build ?
- The build is a process that covers all the various steps that are required to create a deliverable product for your software that can be deployed into various environments like(Dev, test, stage, pre-prod, uat, demo, prod, ......)
- In the JAVA workd tis process typically includes 
    - We should be having a Project folder structure 
    - It will download the dependencies.
    - Copy the dependencies in your project 
    - Compile the code 
    - Execute the code
    - Deploy the code 

## Varioud Build Tools:
- Java > ANT/Maven/Gradle
- .net > Nant/MsBuild
- NodeJs > Node