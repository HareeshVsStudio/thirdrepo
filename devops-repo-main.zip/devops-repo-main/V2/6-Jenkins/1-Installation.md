https://www.jenkins.io/doc/book/installing/linux/

sudo apt install fontconfig openjdk-17-jre

java -version

https://www.jenkins.io/doc/book/installing/linux/#long-term-support-release

