## Setting up master slave configuration
