// Create a pipleline, so that it only exucutes on Pull Requests 

// Create a pipeline, to execute a stage called "scans" when the environment variable is scans=execute 

// so the above condition might be applicable for all brnaches , 

// but when the branch is PR, the condtion should not be coming into picture, and PR should execute the step


