## Install and Deploy node packages with Ansible
* Provision servers manually or using terraform 

* Write ansible playbook to install 
    * node and npm on the server
    * Copy node artifact from controller to node
    * Unpack the artifacts on the respecctive nodes
    * Start the application. 