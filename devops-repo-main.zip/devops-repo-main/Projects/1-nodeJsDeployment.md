# Install and deploy a node application through Ansible 
* Create a server in terraform 
* Configure Ansible across the nodes 
* Install node/npm on a virtal machine 
* build a node application using ansible
    * Copy the artifacts into the server using ansible 
* Deploy/run the same applicaiton using ansible
* Verify if application is running or not using ansible 



