## Install Nexus On the vm using Ansible 
* Provision server manually or using terraform 
* [Refer Here](https://github.com/devopswithcloud/devops-repo/blob/main/Nexus/1_Nexus_Installtion.md) for installation steps 


## `Final Output`:
* When i use the public ip of the vm and access the ip at port 8081 from the browser, i should be able to open nexus.







