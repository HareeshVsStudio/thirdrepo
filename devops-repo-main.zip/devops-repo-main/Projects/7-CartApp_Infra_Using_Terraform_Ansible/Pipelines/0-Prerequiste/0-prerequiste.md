## Pre-requiste 
* Make sure Jenkins master is setup
* Jenkins slave is setup , with maven and java installed already using ansible 
* Make sure slave configuration is already done and tested 

## Create repos in the github
* https://github.com/devopswithcloud/i27-eureka.git
* https://github.com/devopswithcloud/i27-products.git
* https://github.com/devopswithcloud/i27-user.git
* https://github.com/devopswithcloud/i27-clothing.git

## Create a PAT token from github 

## Create Multi Branch Pipeline :
* First create a Multi branch pipeline for eureka


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