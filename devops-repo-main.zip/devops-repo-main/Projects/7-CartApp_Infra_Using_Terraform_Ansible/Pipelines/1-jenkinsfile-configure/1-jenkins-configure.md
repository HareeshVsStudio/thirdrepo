## Creating Jenkinsfile from scratch
* Before starting this, make sure we have github creds configured in jenkins

## Jenkinsfile