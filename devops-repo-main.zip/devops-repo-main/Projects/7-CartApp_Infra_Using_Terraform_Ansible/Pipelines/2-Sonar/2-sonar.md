## Configure Sonar into our pipeline 

* Create/setup our own sonar server 
* Or we can create a account in sonarcloud and perform the same operations
* Why ??
    * It helps in detecting the areas in the code that needs refactoraction or siomplication. It will be acting as a code quality check . 
    * this helps in finding bugs in early stage like dev , so we can fix in at that particular stage only.