# This can be edited lateer
# this is for non ansible machines