## Install and Configure SonarQube

* Create a ansible playbook to install/configure sonarqube on the vm created before.

