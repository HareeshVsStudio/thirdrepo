1. terraform >>>> vm 
2. Ansible >>>> nexus install 