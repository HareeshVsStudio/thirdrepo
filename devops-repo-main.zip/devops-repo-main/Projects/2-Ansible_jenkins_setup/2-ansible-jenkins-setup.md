# Install Configure Jenkins master and slave using ansible

## Configure Jenkins Master
* Create a ansible playbook to install java and jenkins on `Jenkinsmaster` node , created in the previous project. 

## Configure Jenkins Slave
* Create a ansible playbook to install java, maven on the Jenkins Slave.



## Add the JenkinsSlave as a agent to the Jenkins Master