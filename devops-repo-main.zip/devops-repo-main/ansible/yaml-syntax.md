* key and value pairs
```yaml
# yaml representation
name: siva
mobile: 9381062032
cources: 
- GCP
- Docker
- Openshift
address:
  landmark: puppalguda
  city: hyderabad
  state: telangana

```

```bash
# bash 
```